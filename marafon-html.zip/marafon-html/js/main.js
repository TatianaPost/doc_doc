$(function(){
  $('.image-items').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 2000,
    arrows: false,
    centerMode: true,
    variableWidth: true,
    dots:true,
  });


    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            $('.go-top').css('display','flex');
            $('.block-header').addClass('header_fixed');
        } else {
            $('.go-top').attr('style','');
            $('.block-header').removeClass('header_fixed');
        }
    });
    $('.go-top').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });

    $('a[href^="#"], *[data-href^="#"]').on('click', function(e){
            e.preventDefault();
            var t = 1000;
            var d = $(this).attr('data-href') ? $(this).attr('data-href') : $(this).attr('href');
            $('html,body').stop().animate({ scrollTop: $(d).offset().top-200 }, t);
        });
});
